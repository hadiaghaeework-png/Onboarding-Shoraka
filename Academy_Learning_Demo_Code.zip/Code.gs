/*******************************************************
 * آکادمی یادگیری بیمه‌بازار | نسخه نمایشی
 * Google Apps Script + Google Drive + Google Sheets
 *
 * قبل از اجرا:
 * 1) ROOT_FOLDER_ID را با شناسه پوشه اصلی Drive تنظیم کنید.
 * 2) نام پوشه‌های تیم‌ها باید با TEAM_CONFIG هماهنگ باشد.
 * 3) سرویس Advanced Google Services > Drive API v3 را فعال کنید.
 * 4) برای شناسایی ایمیل کاربران، وب‌اپ را با گزینه
 *    Execute as: User accessing the web app منتشر کنید.
 *
 * نکته: DEMO_MODE فقط برای نمایش اولیه است. برای استفاده واقعی
 * آن را false کنید و ایمیل‌ها را در USER_ACCESS تعریف کنید.
 *******************************************************/

const CONFIG = {
  ROOT_FOLDER_ID: '14or5GdiS6QoRbq3fIQWW-Yf0y8s2bUJ8',
  PAGE_SIZE: 12,
  DEMO_MODE: true,
  SPREADSHEET_ID: '', // خالی باشد، با setupAcademy یک فایل ساخته می‌شود.
  QUIZ_SHEET: 'Quizzes',
  ATTEMPTS_SHEET: 'Attempts'
};

const TEAM_CONFIG = [
  { key: 'account', name: 'Account', aliases: ['Account', 'اکانت'], color: 'blue', icon: '◈' },
  { key: 'mlm', name: 'MLM', aliases: ['MLM'], color: 'orange', icon: '◇' },
  { key: 'bnpl', name: 'BNPL', aliases: ['BNPL'], color: 'green', icon: '▣' },
  { key: 'telesales', name: 'Tele Sales', aliases: ['Tele Sales', 'Telesales', 'تله‌سلز'], color: 'purple', icon: '◉' }
];

// در حالت واقعی، ایمیل هر کاربر را در تیم مجاز خودش قرار دهید.
// نمونه:
// 'user@bimebazar.com': { role: 'learner', teams: ['account'] }
// 'manager@bimebazar.com': { role: 'team_manager', teams: ['account'] }
// 'admin@bimebazar.com': { role: 'admin', teams: ['account','mlm','bnpl','telesales'] }
const USER_ACCESS = {
  'admin@bimebazar.com': { role: 'admin', teams: ['account', 'mlm', 'bnpl', 'telesales'] }
};

function doGet() {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle('آکادمی یادگیری | بیمه‌بازار')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function setupAcademy() {
  let ss;
  if (CONFIG.SPREADSHEET_ID) {
    ss = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  } else {
    ss = SpreadsheetApp.create('داده‌های آکادمی یادگیری');
    PropertiesService.getScriptProperties().setProperty('ACADEMY_SPREADSHEET_ID', ss.getId());
    CONFIG.SPREADSHEET_ID = ss.getId();
  }

  let quiz = ss.getSheetByName(CONFIG.QUIZ_SHEET) || ss.insertSheet(CONFIG.QUIZ_SHEET);
  if (quiz.getLastRow() === 0) {
    quiz.appendRow(['ItemId', 'ItemName', 'QuestionsJSON', 'PassScore', 'Active']);
    quiz.appendRow([
      'DEMO-QUIZ',
      'آزمون نمونه آشنایی با سامانه',
      JSON.stringify([
        { q: 'هدف اصلی مسیر یادگیری چیست؟', options: ['ثبت و پیگیری یادگیری', 'حذف کامل آموزش', 'جایگزینی همه جلسات کاری', 'فقط نمایش فایل‌ها'], answer: 0 },
        { q: 'برای ثبت نتیجه آزمون چه چیزی لازم است؟', options: ['ارسال پاسخ‌ها', 'دانلود فایل', 'تغییر نام پوشه', 'بستن صفحه'], answer: 0 }
      ]),
      70,
      true
    ]);
  }

  let attempts = ss.getSheetByName(CONFIG.ATTEMPTS_SHEET) || ss.insertSheet(CONFIG.ATTEMPTS_SHEET);
  if (attempts.getLastRow() === 0) {
    attempts.appendRow(['Timestamp', 'Email', 'ItemId', 'ItemName', 'Score', 'Passed', 'AnswersJSON']);
  }

  PropertiesService.getScriptProperties().setProperty('ACADEMY_SPREADSHEET_ID', ss.getId());
  return { ok: true, spreadsheetUrl: ss.getUrl(), message: 'ساختار داده‌های آکادمی آماده شد.' };
}

function getSpreadsheet_() {
  const id = CONFIG.SPREADSHEET_ID ||
    PropertiesService.getScriptProperties().getProperty('ACADEMY_SPREADSHEET_ID');
  if (!id) throw new Error('ابتدا تابع setupAcademy را اجرا کنید.');
  return SpreadsheetApp.openById(id);
}

function getUserContext() {
  const email = (Session.getActiveUser().getEmail() || '').toLowerCase();
  if (CONFIG.DEMO_MODE) {
    return {
      email: email || 'demo-viewer@demo.local',
      role: 'admin',
      teams: TEAM_CONFIG.map(t => t.key),
      demo: true
    };
  }

  if (!email) throw new Error('ایمیل حساب Google قابل شناسایی نیست. تنظیمات انتشار وب‌اپ را بررسی کنید.');
  const access = USER_ACCESS[email];
  if (!access) throw new Error('برای ورود به آکادمی دسترسی تعریف نشده است.');
  return { email, role: access.role, teams: access.teams || [], demo: false };
}

function getBootstrap() {
  const user = getUserContext();
  const root = Drive.Files.get(CONFIG.ROOT_FOLDER_ID, {
    fields: 'id,name,mimeType',
    supportsAllDrives: true
  });
  const teamFolders = findTeamFolders_(user);
  return {
    user: user,
    rootName: root.name,
    teams: teamFolders,
    pageSize: CONFIG.PAGE_SIZE,
    stats: { teams: teamFolders.length, demo: user.demo }
  };
}

function findTeamFolders_(user) {
  const folders = listChildren_(CONFIG.ROOT_FOLDER_ID, true);
  return TEAM_CONFIG
    .filter(team => user.teams.indexOf(team.key) !== -1)
    .map(team => {
      const folder = folders.find(f =>
        team.aliases.some(alias => f.name.toLowerCase() === alias.toLowerCase())
      );
      return folder ? {
        id: folder.id, key: team.key, name: team.name,
        color: team.color, icon: team.icon, mimeType: folder.mimeType
      } : null;
    })
    .filter(Boolean);
}

function getLibraryPage(folderId, pageToken, searchText, typeFilter, teamKey) {
  const user = getUserContext();
  const allowed = findTeamFolders_(user);
  const team = allowed.find(t => t.key === teamKey);
  if (!team) throw new Error('به این تیم دسترسی ندارید.');
  const targetId = folderId || team.id;
  if (!isWithinTeam_(targetId, team.id)) throw new Error('دسترسی به این پوشه مجاز نیست.');

  const q = ["'"+targetId+"' in parents", 'trashed = false'];
  if (searchText) q.push("name contains '" + escapeQuery_(searchText) + "'");
  if (typeFilter === 'folder') q.push("mimeType = 'application/vnd.google-apps.folder'");
  if (typeFilter === 'file') q.push("mimeType != 'application/vnd.google-apps.folder'");

  const response = Drive.Files.list({
    q: q.join(' and '),
    pageSize: CONFIG.PAGE_SIZE,
    pageToken: pageToken || undefined,
    orderBy: 'folder,name',
    fields: 'nextPageToken,files(id,name,mimeType,mimeType,modifiedTime,size,webViewLink,thumbnailLink,parents)',
    supportsAllDrives: true,
    includeItemsFromAllDrives: true
  });

  const items = (response.files || []).map(f => ({
    id: f.id,
    name: f.name,
    mimeType: f.mimeType,
    kind: f.mimeType === 'application/vnd.google-apps.folder' ? 'folder' : 'file',
    modified: f.modifiedTime || '',
    size: formatSize_(f.size),
    url: f.webViewLink || ('https://drive.google.com/open?id=' + f.id),
    thumbnail: f.thumbnailLink || '',
    icon: fileIcon_(f.mimeType),
    quiz: getQuizMeta_(f.id)
  }));

  return {
    items: items,
    nextPageToken: response.nextPageToken || '',
    hasMore: !!response.nextPageToken,
    folderId: targetId,
    folderName: getDriveName_(targetId)
  };
}

function isWithinTeam_(targetId, teamRootId) {
  if (targetId === teamRootId) return true;
  let current = targetId;
  for (let i = 0; i < 30; i++) {
    const meta = Drive.Files.get(current, { fields: 'id,parents', supportsAllDrives: true });
    const parents = meta.parents || [];
    if (parents.indexOf(teamRootId) !== -1) return true;
    if (!parents.length) return false;
    current = parents[0];
    if (current === teamRootId) return true;
  }
  return false;
}

function getQuizMeta_(itemId) {
  try {
    const sheet = getSpreadsheet_().getSheetByName(CONFIG.QUIZ_SHEET);
    if (!sheet || sheet.getLastRow() < 2) return { available: false };
    const rows = sheet.getDataRange().getValues();
    for (let i = 1; i < rows.length; i++) {
      if (String(rows[i][0]) === String(itemId) && rows[i][4] !== false) {
        return { available: true, passScore: Number(rows[i][3]) || 70 };
      }
    }
  } catch (e) {}
  return { available: false };
}

function getQuiz(itemId) {
  getUserContext();
  const sheet = getSpreadsheet_().getSheetByName(CONFIG.QUIZ_SHEET);
  const rows = sheet.getDataRange().getValues();
  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][0]) === String(itemId) && rows[i][4] !== false) {
      const questions = JSON.parse(rows[i][2]);
      return {
        itemId: String(rows[i][0]),
        itemName: String(rows[i][1]),
        passScore: Number(rows[i][3]) || 70,
        questions: questions.map(q => ({ q: q.q, options: q.options }))
      };
    }
  }
  throw new Error('برای این محتوا هنوز آزمونی تعریف نشده است.');
}

function submitQuiz(itemId, answers) {
  const user = getUserContext();
  const sheet = getSpreadsheet_().getSheetByName(CONFIG.QUIZ_SHEET);
  const rows = sheet.getDataRange().getValues();
  let quiz = null;
  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][0]) === String(itemId) && rows[i][4] !== false) {
      quiz = { id: String(rows[i][0]), name: String(rows[i][1]), pass: Number(rows[i][3]) || 70, questions: JSON.parse(rows[i][2]) };
      break;
    }
  }
  if (!quiz) throw new Error('آزمون پیدا نشد.');

  let correct = 0;
  quiz.questions.forEach((q, i) => { if (Number(answers[i]) === Number(q.answer)) correct++; });
  const score = Math.round((correct / quiz.questions.length) * 100);
  const passed = score >= quiz.pass;
  getSpreadsheet_().getSheetByName(CONFIG.ATTEMPTS_SHEET).appendRow([
    new Date(), user.email, quiz.id, quiz.name, score, passed, JSON.stringify(answers)
  ]);
  return { score, passed, correct, total: quiz.questions.length, passScore: quiz.pass };
}

function listChildren_(folderId, foldersOnly) {
  const q = ["'"+folderId+"' in parents", 'trashed = false'];
  if (foldersOnly) q.push("mimeType = 'application/vnd.google-apps.folder'");
  const res = Drive.Files.list({
    q: q.join(' and '),
    pageSize: 1000,
    fields: 'files(id,name,mimeType)',
    supportsAllDrives: true,
    includeItemsFromAllDrives: true
  });
  return res.files || [];
}

function getDriveName_(id) {
  return Drive.Files.get(id, { fields: 'name', supportsAllDrives: true }).name;
}

function fileIcon_(mime) {
  if (mime === 'application/pdf') return 'PDF';
  if (mime && mime.indexOf('video/') === 0) return 'VIDEO';
  if (mime && mime.indexOf('image/') === 0) return 'IMAGE';
  if (mime && mime.indexOf('spreadsheet') !== -1) return 'SHEET';
  if (mime && mime.indexOf('document') !== -1) return 'DOC';
  if (mime === 'application/vnd.google-apps.folder') return 'FOLDER';
  return 'FILE';
}

function formatSize_(bytes) {
  if (!bytes) return '';
  const n = Number(bytes);
  return n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
}

function escapeQuery_(s) {
  return String(s).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
}
